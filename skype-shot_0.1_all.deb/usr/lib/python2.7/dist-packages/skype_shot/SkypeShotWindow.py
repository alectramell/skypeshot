# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# 
# Affiliations..
# 
# Skype Instant Messenger
# http://www.skype.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os

from locale import gettext as _

from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('skype_shot')

from skype_shot_lib import Window
from skype_shot.AboutSkypeShotDialog import AboutSkypeShotDialog
from skype_shot.PreferencesSkypeShotDialog import PreferencesSkypeShotDialog

# See skype_shot_lib.Window.py for more details about how this class works
class SkypeShotWindow(Window):
    __gtype_name__ = "SkypeShotWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(SkypeShotWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutSkypeShotDialog
        self.PreferencesDialog = PreferencesSkypeShotDialog

        # Code for other initialization actions should be added here.

        self.shotbutton = self.builder.get_object('shotbutton')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.skypebutton = self.builder.get_object('skypebutton')
        self.entry1 = self.builder.get_object('entry1')

        os.system('skype &')

    def on_entry1_activate(self, widget):
	    user = self.entry1.get_text()
        os.system('clear')
        os.system('skype skype:' + user + '?chat &')

    def on_shotbutton_clicked(self, widget):
	    user = self.entry1.get_text()
        os.system('clear')
        os.system('skype skype:' + user + '?chat &')

    def on_skypebutton_clicked(self, widget):
        os.system('clear')
        os.system('skype &')

    def on_exitbutton_clicked(self, widget):
        os.system('clear')
        os.system('killall skype')
        exit()






